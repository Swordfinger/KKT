# 贡献指南

感谢参与“遇见”。项目仍处于私有 MVP 阶段，尚未选定开源许可证。开始较大工作前，请先在 Issue 中确认范围。

## 开发流程

1. 从最新 `main` 创建短期分支：`feature/<issue>-<topic>`、`fix/<issue>-<topic>` 或 `docs/<issue>-<topic>`。
2. 一次 Pull Request 只解决一个明确问题，避免顺手重构无关代码。
3. 不提交 `.env`、数据库、用户资料、日志、`dist/`、`outputs/` 或 `work/`。
4. 改动数据模型时，同时更新 `db/schema.ts`、迁移文件和相应测试。
5. 改动推荐规则时，写明公平性、隐私与额度影响。
6. 提交前运行 `pnpm verify`。

## 提交与审查

推荐使用简短的 Conventional Commits，例如 `feat: add user blocking`、`fix: enforce export ownership`。PR 描述应说明触发场景、改变后的行为、数据迁移、风险和验证结果。至少一名其他协作者审查后再合并；涉及认证、支付、隐私、删除数据或数据库迁移的 PR 必须由项目负责人审查。

建议采用受保护的 `main`、短期功能分支和 squash merge。第一批提交建议拆为：仓库基线文档；CI 与检查；现有应用源码；后续每个产品功能单独提交。

## 本地验证

```bash
pnpm install --frozen-lockfile
pnpm verify
```

手工验证 UI 时使用测试账号和虚构生辰，不使用真实个人信息。发现安全问题时不要创建公开 Issue；仓库建立后使用 GitHub Security Advisory 私下报告。
