import { readdirSync, readFileSync, statSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { extname, join, relative } from 'node:path';

const root = process.cwd();
const sourceRoots = ['server', 'tests', 'scripts'];
const extensions = new Set(['.js', '.mjs', '.cjs']);
const ignored = new Set(['node_modules', '.git', 'dist', 'data', 'work', 'outputs']);
const failures = [];

function walk(path) {
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    if (ignored.has(entry.name)) continue;
    const full = join(path, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (extensions.has(extname(entry.name))) {
      const result = spawnSync(process.execPath, ['--check', full], { encoding: 'utf8' });
      if (result.status !== 0) failures.push(`${relative(root, full)}\n${result.stderr}`);
    }
  }
}

for (const directory of sourceRoots) walk(join(root, directory));

const candidates = ['.env', 'data/yujian.sqlite', 'work/register-preview.sqlite', 'dist/index.html'];
for (const candidate of candidates) {
  const check = spawnSync('git', ['check-ignore', '--quiet', '--', candidate]);
  if (check.status !== 0) failures.push(`${candidate} 应被 .gitignore 排除`);
}

const required = ['README.md', 'CONTRIBUTING.md', 'SECURITY.md', '.env.example', 'docs/ROADMAP.md'];
for (const file of required) {
  try {
    if (!statSync(join(root, file)).isFile() || readFileSync(join(root, file), 'utf8').trim() === '') failures.push(`${file} 为空`);
  } catch {
    failures.push(`缺少 ${file}`);
  }
}

if (failures.length) {
  console.error(failures.join('\n\n'));
  process.exit(1);
}
console.log('Repository checks passed.');
