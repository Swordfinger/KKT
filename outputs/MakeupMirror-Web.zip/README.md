# 映妆 · 手机网页版

面向只有 Windows 电脑、希望在 iPhone 上使用的用户。使用 HTTPS 链接在 Safari 中打开，可添加到主屏幕。不是 App Store 原生安装包；原生 Swift 项目另行保留。

已实现前后相机切换、MediaPipe 本机人脸定位、腮红与唇线叠加、四步教学、三种教学风格、拍摄位置检查、暂停、中文语音，以及柔和/自然两种语音设置与试听。离开页面关闭相机。不保存或上传摄像头画面。

人脸定位采用 MediaPipe Tasks Vision 0.10.21，模型与 WASM 随应用同源提供。识别约每 110ms 触发一次，实际速度取决于设备。预览持续播放，叠加采用最近的定位结果；快速移动可能有延迟。尚未真机验证 iPhone 摄像头、语音和性能。

柔和语音将语速调至 0.78、音量 0.72、音调 1.06，并优先选择系统可用中文女声。具体音色由设备安装的语音决定，并非固定录制的人声。

不包含个性化五官/身材审美分析、自动妆效评价、发型建议、视频库或语音口令。当前腮红引导为关键点位置上的通用示意。不会把“用户点击完成”解释为 AI 已确认妆效。

部署：静态目录为 dist，Sites 身份位于 .openai/hosting.json。无外部 API 密钥。站点默认仅创建者可访问，手机如提示登录需使用同一账号。浏览器需要联网下载模型，未提供离线保证。

第三方：MediaPipe 项目 LICENSE 在 dist/vendor/LICENSE。模型来源为 https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task 。技术参考：https://developers.google.com/edge/mediapipe/solutions/vision/face_landmarker/web_js

待真机验收：Safari/主屏幕访问、首次允许及拒绝权限、相机切换、后台恢复、多脸/遮挡/侧脸、连续使用温升、柔和语音试听。
