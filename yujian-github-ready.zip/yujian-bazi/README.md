# 遇见 · 八字合缘

“遇见”是一个处于 MVP 阶段的中文交友应用。用户填写公开资料、生辰和择偶偏好后，服务端依据年龄、双方偏好和八字合缘参考分配双向推荐。八字分数只作传统文化趣味参考，不能替代真实沟通或专业建议。

## 当前功能

- 本地账号注册、登录、退出和 30 天会话
- 个人资料、出生日期/时间、兴趣与交友偏好
- 服务端八字排盘与合缘评分
- 同一候选人双向出现的推荐分配
- 每位用户按北京时间每天累计最多收到 20 人推荐；跳过不返还额度
- 每位用户同时喜欢最多 20 人，支持取消和双向喜欢提示
- 精确生辰、八字原始数据、登录名和密码摘要不向其他用户公开
- SQLite 本地运行；D1/Worker 构建用于 Sites 部署

当前完成度、风险和待办见 [开发进度](docs/PROGRESS.md)、[项目现状](docs/STATUS.md) 与 [路线图](docs/ROADMAP.md)。

## 技术栈与目录

- Node.js 24、原生 HTTP 服务和 `node:sqlite`
- SQLite / Cloudflare D1 兼容 SQL，Drizzle 负责 schema 与迁移生成
- 无框架 HTML、CSS、JavaScript 前端
- Node 内置测试运行器；esbuild 打包 Worker

```text
server/          API、匹配服务、本地服务和前端源码
db/              Drizzle schema
drizzle/         数据库迁移与约束触发器
tests/           后端规则与安全边界测试
scripts/         仓库检查脚本
docs/            架构、路线图、商业化与任务清单
.github/         CI、Issue 与 PR 模板
outputs/         早期离线原型（本地保留，不提交）
data/ work/      本地数据库与临时文件（不提交）
dist/            构建产物（不提交）
```

## 本地启动

要求 Node.js 24+ 与 pnpm。仓库中没有生产密钥；可参考 `.env.example` 配置进程环境变量。

```bash
pnpm install --frozen-lockfile
pnpm start
```

打开 `http://127.0.0.1:4175`。首次启动会在 `data/yujian.sqlite` 创建本地数据库。不要把 `data/` 上传到 GitHub。

## 检查、测试和构建

```bash
pnpm check
pnpm test
pnpm build
# 或一次执行全部检查
pnpm verify
```

`pnpm build` 将 Sites Worker 和数据库迁移写到 `dist/`。本地 Docker 运行方式：

```bash
docker build -t yujian-bazi .
docker run --rm -p 4175:4175 -v yujian-data:/app/data yujian-bazi
```

Sites 部署前把 `.openai/hosting.example.json` 复制为 `.openai/hosting.json`，再填入你自己的项目 ID。真实绑定文件只保留在本机，不提交。

## 配置

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `HOST` | `127.0.0.1` | 本地监听地址；容器中使用 `0.0.0.0` |
| `PORT` | `4175` | HTTP 端口 |
| `DATABASE_PATH` | `./data/yujian.sqlite` | SQLite 文件路径 |
| `PUBLIC_ORIGIN` | 根据请求 Host 推导 | 反向代理后的公开源地址，生产环境必须固定为 HTTPS 地址 |

## 部署状态

仓库已有 Dockerfile 和 Sites/D1 构建配置，但尚未完成正式生产部署。发布前必须完成举报与拉黑、账号删除与数据导出、法律文本、生产监控、备份恢复和安全复核。不要直接把当前 MVP 用于真实用户数据。

## 协作

请先阅读 [GitHub 上传清单](docs/GITHUB_SETUP.md)、[贡献指南](CONTRIBUTING.md) 和 [架构说明](docs/ARCHITECTURE.md)。可独立领取的工作见 [GitHub Issues 清单](docs/BACKLOG.md)。本项目尚未确定开源许可证；在所有者确认前，默认保留全部权利，外部贡献需要先获得维护者同意。
