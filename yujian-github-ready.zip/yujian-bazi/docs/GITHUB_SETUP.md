# GitHub 上传与协作清单

## 上传前

1. 建议先建立私有仓库，完成安全与合规功能后再考虑公开。
2. 在 GitHub **Settings → Emails** 复制自己的 `noreply` 邮箱，避免个人邮箱写入公开提交历史。
3. 在本项目内设置提交身份，不修改电脑上的全局配置：

```bash
git config user.name "你的 GitHub 显示名"
git config user.email "你的 GitHub noreply 邮箱"
```

4. 运行 `pnpm verify`，并确认 `git status --ignored --short` 中数据库、环境文件、`dist/`、`outputs/` 和 `work/` 都显示为忽略。

## 建议的初始提交

当前仓库还没有提交。可以按以下顺序建立易审查的历史：

1. `feat: add bazi matching service and database schema`：`server/`、`db/`、`drizzle/`、Dockerfile 和包管理文件。
2. `test: cover recommendation and like limits`：`tests/`。
3. `chore: add repository checks and continuous integration`：`scripts/`、`.github/workflows/`、`.gitignore`、`.env.example` 和 Sites 示例配置。
4. `docs: document product status and collaboration workflow`：README、贡献/安全说明、`docs/` 和 Issue/PR 模板。

每一步提交前再次运行 `git diff --cached --stat` 和 `git diff --cached`。

## 连接 GitHub

在 GitHub 创建一个**空仓库**，不要让 GitHub 自动生成 README、许可证或 `.gitignore`。然后执行：

```bash
git remote add origin https://github.com/OWNER/REPOSITORY.git
git push -u origin main
```

推送后在仓库设置中：

- 保护 `main`，要求 Pull Request、CI 通过和至少一名审查者。
- 开启 Dependabot alerts、私密漏洞报告和自动删除已合并分支。
- 邀请朋友使用 Write 权限，不直接授予 Admin。
- 按 `docs/BACKLOG.md` 创建 Issues，并让每人领取独立任务。

## 首批协作分支

使用 `feature/<issue>-<topic>`、`fix/<issue>-<topic>` 和 `docs/<issue>-<topic>`。优先分配 `SAFE-01`、`DATA-01`、`TEST-01` 和 `OPS-01`，它们边界清晰，适合多人并行。
